package flocking;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Jason Brownlee
 * @version 1.0
 */

public class Main
{
    /**
     * entry point into the application
     * @param args
     */
    public static void main(String [] args)
    {
        new UniverseFrame();
    }
}